<?php
/**
 * verificar_pagamento.php
 * Retorna o status de uma transação PIX pelo txid.
 *
 * GET /verificar_pagamento.php?txid={txid}
 *
 * Resposta:
 *   { "status": "waiting_paid" }  ou  { "status": "paid" }
 */

header('Content-Type: application/json; charset=utf-8');

// Sanitiza o txid — apenas alfanumérico
$txid = preg_replace('/[^a-zA-Z0-9]/', '', $_GET['txid'] ?? '');

if (empty($txid)) {
    http_response_code(400);
    echo json_encode(['erro' => 'txid inválido.']);
    exit;
}

$file = __DIR__ . '/transactions/' . $txid . '.json';

if (!file_exists($file)) {
    http_response_code(404);
    echo json_encode(['erro' => 'Transação não encontrada.']);
    exit;
}

$data   = json_decode(file_get_contents($file), true) ?? [];
$status = $data['status'] ?? 'waiting_paid';

echo json_encode(['txid' => $txid, 'status' => $status]);

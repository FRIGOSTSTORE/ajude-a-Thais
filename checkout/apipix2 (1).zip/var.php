<?php

$URL_API = "https://api.pix.basspago.com.br";
$SENHA_CASH_IN = "d.WWxgdpH_r3nv2HCMJcYxH-K8xkJqPJJuAH7V2Tp2CNbugdDWc!nbvH7a2X";   
$CLIENT_ID = "00011193760124794000127";
$CLIENT_SECRET = "mNhMDcwNTItYTc4Ni00MjE1LThlOGEtZ";

$CHAVE_PIX = "fcd47d4c-bd68-440a-8480-9c5a6c184abc";

// ── Facebook Conversions API ──────────────────────────────────────────────────
$FB_PIXEL_ID      = "1520472869160223";  
$FB_ACCESS_TOKEN  = "EAASgeovzo6wBSBf22mtIitPIzP59EXMZBB1rc093X5iAWJZCMwIRW6bS7tMzjp09sVIuBSmtdCNWgrMimhJc1cMKCYrFTZCTNt39RVJqjxfHQcTssNnq0k3b51pJfjUrYsy7a2O1kupfyBm7IjxyJVztIH1lEtncx8EFUE7F1L1Pn47EHUgTQOZBmVFCsQZDZD";  

// ── UTMify ────────────────────────────────────────────────────────────────────
$UTMIFY_API_TOKEN = "3K02ny3fWCrqJ6ZPHsE52YSZnR25qhWRjcj5";   // Token de API do UTMify
$NOME_PRODUTO = "Produto Digital";   // Nome que aparece no painel UTMify
$ID_PRODUTO   = "produto-001";       // ID interno do produto

$API_KEY = "a4f5d95862b7c5238cd957db82b3482e0b7de358fe65c50f5c6d08985f85dd3c";

?>
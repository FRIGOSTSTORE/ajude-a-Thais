<?php
/**
 * webhook_pix.php — Recebe notificações do BASSPAGO quando um PIX é pago.
 *
 * Configure esta URL no painel do BASSPAGO:
 *   PUT /webhook/{chave}  →  webhookUrl: "https://seudominio.com/apipix/webhook_pix.php"
 *
 * Payload recebido:
 * {
 *   "pix": [
 *     {
 *       "endToEndId": "E1234...",
 *       "txid":       "cd1fe328...",
 *       "valor":      "100.00",
 *       "horario":    "2024-01-01T12:00:00.000Z",
 *       "infoPagador": "..."
 *     }
 *   ]
 * }
 */

require_once __DIR__ . '/tracker.php';

header('Content-Type: application/json; charset=utf-8');

// Só aceita POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit;
}

$raw = file_get_contents('php://input');

// Loga o payload bruto para debug (opcional — remova em produção se desnecessário)
file_put_contents(
    __DIR__ . '/transactions/_webhook_log.txt',
    date('Y-m-d H:i:s') . ' ' . $raw . PHP_EOL,
    FILE_APPEND | LOCK_EX
);

$payload = json_decode($raw, true);

if (empty($payload['pix']) || !is_array($payload['pix'])) {
    http_response_code(200); // Responde 200 para não gerar retry desnecessário
    echo json_encode(['ok' => false, 'msg' => 'Nenhum pix no payload']);
    exit;
}

$tracker = new Tracker();

foreach ($payload['pix'] as $pix) {
    $txid = $pix['txid'] ?? null;
    if (!$txid) continue;

    // Carrega dados da transação salva na criação do QR Code
    $txData = carregarTransacao($txid);

    // Idempotência: ignora se já processado
    if (($txData['status'] ?? '') === 'paid') continue;

    $data = array_merge($txData, [
        'txid'   => $txid,
        'valor'  => $pix['valor']   ?? ($txData['valor']  ?? '0.00'),
        'paidAt' => isset($pix['horario'])
            ? date('Y-m-d H:i:s', strtotime($pix['horario']))
            : date('Y-m-d H:i:s'),
        'endToEndId' => $pix['endToEndId'] ?? null,
    ]);

    $tracker->purchase($data);

    // Marca transação como paga
    salvarTransacao($txid, array_merge($txData, ['status' => 'paid', 'paidAt' => $data['paidAt']]));
}

http_response_code(200);
echo json_encode(['ok' => true]);

// ─────────────────────────────────────────────────────────────────────────────

function carregarTransacao(string $txid): array
{
    $file = __DIR__ . '/transactions/' . preg_replace('/[^a-zA-Z0-9]/', '', $txid) . '.json';
    if (!file_exists($file)) return [];
    $data = json_decode(file_get_contents($file), true);
    return is_array($data) ? $data : [];
}

function salvarTransacao(string $txid, array $data): void
{
    $file = __DIR__ . '/transactions/' . preg_replace('/[^a-zA-Z0-9]/', '', $txid) . '.json';
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX);
}
